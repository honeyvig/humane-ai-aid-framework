# 05_robotics_models.md

Stationary units, rovers, optional humanoids.