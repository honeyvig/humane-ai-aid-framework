# 09_risk_failure_modes.md

Misuse risks, failure scenarios, mitigations.