# 02_single_city_pilot.md

Pilot deployment for one metropolitan area.