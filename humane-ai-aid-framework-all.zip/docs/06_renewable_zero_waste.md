# 06_renewable_zero_waste.md

Energy, materials, circular economy design.