# 03_rural_remote_model.md

Rover-based deployment for rural, deserts, forests.