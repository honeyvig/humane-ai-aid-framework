# 04_ai_neural_llm_stack.md

Perception, reasoning, control, governance AI layers.