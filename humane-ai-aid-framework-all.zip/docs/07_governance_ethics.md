# 07_governance_ethics.md

Consent, audits, legal compatibility, safeguards.