# 08_funding_execution.md

NGO, public funding, phased rollout (5–20 years).