# 01_system_architecture.md

Complete layered architecture from energy to recycling.