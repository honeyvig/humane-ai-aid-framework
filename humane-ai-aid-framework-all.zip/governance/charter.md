## Humanitarian AI Charter
- Aid-only purpose
- No identity resolution
- No law enforcement use
- Community veto power
- Open audits